package com.example.wonholimapplicationlab1designbusiness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private Button button2;
    private Button button3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open(v);
            }
        });
        button2 = (Button) findViewById(R.id.button3);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open2(v);
            }
        });
        button3 = (Button) findViewById(R.id.button4);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open3(v);
            }
        });
    }

    public void open(View view){
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://juego11.com/bbs/board.php?bo_table=order"));
        startActivity(browserIntent);
    }
    public void open2(View view){
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://juego11.com/bbs/board.php?bo_table=010301&wr_id=9"));
        startActivity(browserIntent);
    }
    public void open3(View view){
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://juego11.com/"));
        startActivity(browserIntent);
    }

}
