package com.example.koreanapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class sec1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec1);
    }
}
